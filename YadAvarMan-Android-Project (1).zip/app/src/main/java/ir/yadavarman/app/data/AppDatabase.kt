package ir.yadavarman.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "items")
data class NoteTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val isTask: Boolean,
    val completed: Boolean = false,
    val important: Boolean = false,
    val reminderAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface NoteTaskDao {
    @Query("SELECT * FROM items ORDER BY important DESC, completed ASC, createdAt DESC")
    fun observeAll(): Flow<List<NoteTask>>

    @Query("SELECT * FROM items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): NoteTask?

    @Insert
    suspend fun insert(item: NoteTask): Long

    @Update
    suspend fun update(item: NoteTask)

    @Delete
    suspend fun delete(item: NoteTask)
}

@Database(entities = [NoteTask::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): NoteTaskDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "yadavarman.db"
                ).build().also { INSTANCE = it }
            }
    }
}
