package ir.yadavarman.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.yadavarman.app.data.AppDatabase
import ir.yadavarman.app.data.NoteTask
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Purple = Color(0xFF6C63FF)
private val DarkBg = Color(0xFF101116)
private val Card = Color(0xFF1B1D27)

class MainViewModel(private val db: AppDatabase) : ViewModel() {
    val items = db.dao().observeAll().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList()
    )

    fun add(title: String, body: String, isTask: Boolean, important: Boolean, reminderAt: Long?) =
        viewModelScope.launch {
            db.dao().insert(
                NoteTask(title = title.trim(), body = body.trim(), isTask = isTask,
                    important = important, reminderAt = reminderAt)
            )
        }

    fun toggle(item: NoteTask) = viewModelScope.launch {
        db.dao().update(item.copy(completed = !item.completed))
    }

    fun toggleImportant(item: NoteTask) = viewModelScope.launch {
        db.dao().update(item.copy(important = !item.important))
    }

    fun delete(item: NoteTask) = viewModelScope.launch { db.dao().delete(item) }
}

class MainViewModelFactory(private val db: AppDatabase) : androidx.lifecycle.ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T =
        MainViewModel(db) as T
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val db = remember { AppDatabase.get(this) }
            val vm: MainViewModel = viewModel(factory = MainViewModelFactory(db))
            YadAvarTheme { App(vm, this) }
        }
    }
}

@Composable
fun YadAvarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple,
            background = DarkBg,
            surface = Card,
            onBackground = Color.White,
            onSurface = Color.White
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App(vm: MainViewModel, context: Context) {
    val items by vm.items.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    val filtered = items.filter {
        it.title.contains(search, true) || it.body.contains(search, true)
    }.filter {
        when (tab) {
            1 -> it.isTask
            2 -> !it.isTask
            3 -> it.important
            else -> true
        }
    }

    Scaffold(
        containerColor = DarkBg,
        topBar = {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("یادآور من", style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold)
                        Text("کارها و یادداشت‌ها، یکجا", color = Color.LightGray)
                    }
                    IconButton(onClick = { showAdd = true }) {
                        Icon(Icons.Default.AddCircle, "افزودن", tint = Purple,
                            modifier = Modifier.size(38.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("جست‌وجو در یادداشت‌ها و کارها…") },
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    singleLine = true,
                    shape = RoundedCornerShape(18.dp)
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf(
                    Icons.Default.Home to "همه",
                    Icons.Default.CheckCircle to "کارها",
                    Icons.Default.Notes to "یادداشت‌ها",
                    Icons.Default.Star to "مهم"
                ).forEachIndexed { i, pair ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(pair.first, null) },
                        label = { Text(pair.second) }
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Purple) {
                Icon(Icons.Default.Add, "افزودن")
            }
        }
    ) { padding ->
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Inbox, null, modifier = Modifier.size(72.dp),
                        tint = Color.Gray)
                    Spacer(Modifier.height(10.dp))
                    Text("هنوز چیزی اینجا نیست", color = Color.Gray)
                    Text("با دکمه + اولین موردت را بساز", color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filtered, key = { it.id }) { item ->
                    ItemCard(item, vm)
                }
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onSave = { title, body, isTask, important, reminder ->
                vm.add(title, body, isTask, important, reminder)
                if (reminder != null) scheduleReminder(context, title, body, reminder)
                showAdd = false
            }
        )
    }
}

@Composable
fun ItemCard(item: NoteTask, vm: MainViewModel) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Card),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.Top) {
            if (item.isTask) {
                Checkbox(checked = item.completed, onCheckedChange = { vm.toggle(item) })
            } else {
                Icon(Icons.Default.Notes, null, tint = Purple, modifier = Modifier.padding(8.dp))
            }

            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text(
                    item.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (item.completed) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                )
                if (item.body.isNotBlank()) {
                    Spacer(Modifier.height(4.dp))
                    Text(item.body, color = Color.LightGray, maxLines = 3)
                }
                item.reminderAt?.let {
                    Spacer(Modifier.height(8.dp))
                    Text("یادآوری: ${formatDate(it)}", color = Purple,
                        style = MaterialTheme.typography.labelMedium)
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(onClick = { vm.toggleImportant(item) }) {
                    Icon(
                        if (item.important) Icons.Default.Star else Icons.Default.StarBorder,
                        null, tint = if (item.important) Color(0xFFFFC857) else Color.Gray
                    )
                }
                IconButton(onClick = { vm.delete(item) }) {
                    Icon(Icons.Default.DeleteOutline, null, tint = Color.Gray)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, Boolean, Boolean, Long?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var isTask by remember { mutableStateOf(true) }
    var important by remember { mutableStateOf(false) }
    var reminder by remember { mutableStateOf(false) }
    var selectedTime by remember { mutableStateOf<Long?>(null) }
    var showTime by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("مورد جدید") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("عنوان") },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(body, { body = it }, label = { Text("توضیحات") },
                    minLines = 3, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("نوع: ")
                    FilterChip(selected = isTask, onClick = { isTask = true }, label = { Text("کار") })
                    Spacer(Modifier.width(8.dp))
                    FilterChip(selected = !isTask, onClick = { isTask = false }, label = { Text("یادداشت") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(important, { important = it })
                    Text("مهم")
                    Spacer(Modifier.width(12.dp))
                    Checkbox(reminder, {
                        reminder = it
                        if (it) showTime = true else selectedTime = null
                    })
                    Text("یادآوری")
                }
                selectedTime?.let { Text("زمان انتخاب‌شده: ${formatDate(it)}", color = Purple) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = { onSave(title, body, isTask, important, selectedTime) }
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )

    if (showTime) {
        val picker = rememberTimePickerState()
        AlertDialog(
            onDismissRequest = { showTime = false },
            confirmButton = {
                TextButton(onClick = {
                    val now = Calendar.getInstance()
                    now.set(Calendar.HOUR_OF_DAY, picker.hour)
                    now.set(Calendar.MINUTE, picker.minute)
                    now.set(Calendar.SECOND, 0)
                    if (now.timeInMillis <= System.currentTimeMillis()) now.add(Calendar.DAY_OF_YEAR, 1)
                    selectedTime = now.timeInMillis
                    showTime = false
                }) { Text("تأیید") }
            },
            dismissButton = { TextButton({ showTime = false }) { Text("لغو") } },
            title = { Text("زمان یادآوری") },
            text = { TimePicker(state = picker) }
        )
    }
}

private fun formatDate(ms: Long): String =
    SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale("fa")).format(Date(ms))

private fun scheduleReminder(context: Context, title: String, body: String, at: Long) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, ReminderReceiver::class.java).apply {
        putExtra("title", title)
        putExtra("body", body.ifBlank { "زمان انجام این کار رسیده است." })
    }
    val requestCode = (at % Int.MAX_VALUE).toInt()
    val pending = PendingIntent.getBroadcast(
        context, requestCode, intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    if (android.os.Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()) {
        alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending)
    } else {
        alarm.set(AlarmManager.RTC_WAKEUP, at, pending)
    }
}
