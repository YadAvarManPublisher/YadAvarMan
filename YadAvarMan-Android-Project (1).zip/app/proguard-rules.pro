# YadAvarMan - no custom rules required for the MVP.
