package ir.yadavarman.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "items")
data class NoteTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String = "",
    val isTask: Boolean,
    val completed: Boolean = false,
    val important: Boolean = false,
    val reminderAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val priority: Int = 1,
    val category: String = "عمومی"
)

@Entity(tableName = "goals")
data class Goal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val progress: Int = 0,
    val important: Boolean = false,
    val completed: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface NoteTaskDao {
    @Query("SELECT * FROM items ORDER BY completed ASC, important DESC, priority DESC, createdAt DESC")
    fun observeAll(): Flow<List<NoteTask>>
    @Insert suspend fun insert(item: NoteTask): Long
    @Update suspend fun update(item: NoteTask)
    @Delete suspend fun delete(item: NoteTask)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY completed ASC, important DESC, createdAt DESC")
    fun observeAll(): Flow<List<Goal>>
    @Insert suspend fun insert(goal: Goal): Long
    @Update suspend fun update(goal: Goal)
    @Delete suspend fun delete(goal: Goal)
}

@Database(entities = [NoteTask::class, Goal::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): NoteTaskDao
    abstract fun goalDao(): GoalDao
    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "yadavarman.db"
            ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
        }
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE items ADD COLUMN priority INTEGER NOT NULL DEFAULT 1")
                db.execSQL("ALTER TABLE items ADD COLUMN category TEXT NOT NULL DEFAULT 'عمومی'")
                db.execSQL("""CREATE TABLE IF NOT EXISTS goals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    title TEXT NOT NULL,
                    description TEXT NOT NULL,
                    progress INTEGER NOT NULL,
                    important INTEGER NOT NULL,
                    completed INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL
                )""")
            }
        }
    }
}
