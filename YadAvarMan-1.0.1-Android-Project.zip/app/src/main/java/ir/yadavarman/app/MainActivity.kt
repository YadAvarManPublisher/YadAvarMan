package ir.yadavarman.app

import android.app.*
import android.content.*
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import ir.yadavarman.app.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val Purple = Color(0xFF6C63FF)
private val Bg = Color(0xFF101116)
private val Card = Color(0xFF1B1D27)

class MainViewModel(private val db: AppDatabase) : ViewModel() {
    val items = db.dao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val goals = db.goalDao().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addTask(title:String, body:String, important:Boolean, priority:Int, category:String, reminder:Long?) = viewModelScope.launch {
        db.dao().insert(NoteTask(title.trim(), body.trim(), true, important=important, reminderAt=reminder, priority=priority, category=category))
    }
    fun addNote(title:String, body:String) = viewModelScope.launch {
        db.dao().insert(NoteTask(title.trim(), body.trim(), false, category="یادداشت"))
    }
    fun toggle(item:NoteTask) = viewModelScope.launch { db.dao().update(item.copy(completed=!item.completed)) }
    fun star(item:NoteTask) = viewModelScope.launch { db.dao().update(item.copy(important=!item.important)) }
    fun delete(item:NoteTask) = viewModelScope.launch { db.dao().delete(item) }
    fun addGoal(title:String, desc:String, important:Boolean) = viewModelScope.launch { db.goalDao().insert(Goal(title=title.trim(),description=desc.trim(),important=important)) }
    fun progress(goal:Goal, delta:Int) = viewModelScope.launch {
        val p=(goal.progress+delta).coerceIn(0,100)
        db.goalDao().update(goal.copy(progress=p, completed=p==100))
    }
    fun star(goal:Goal) = viewModelScope.launch { db.goalDao().update(goal.copy(important=!goal.important)) }
    fun delete(goal:Goal) = viewModelScope.launch { db.goalDao().delete(goal) }
}
class VMFactory(private val db:AppDatabase): androidx.lifecycle.ViewModelProvider.Factory {
    override fun <T:ViewModel> create(c:Class<T>):T = MainViewModel(db) as T
}

class MainActivity:ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val db=remember { AppDatabase.get(this) }
            val vm:MainViewModel=viewModel(factory=VMFactory(db))
            YadAvarTheme { App(vm,this) }
        }
    }
}
@Composable fun YadAvarTheme(content:@Composable()->Unit) {
    MaterialTheme(colorScheme=darkColorScheme(primary=Purple,background=Bg,surface=Card,onSurface=Color.White,onBackground=Color.White),content=content)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun App(vm:MainViewModel, context:Context) {
    val items by vm.items.collectAsState()
    val goals by vm.goals.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var search by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    var addGoal by remember { mutableStateOf(false) }
    var focus by remember { mutableStateOf(false) }

    val tasks=items.filter { it.isTask && (it.title.contains(search,true)||it.body.contains(search,true)) }
    val notes=items.filter { !it.isTask && (it.title.contains(search,true)||it.body.contains(search,true)) }
    val visible=when(tab){1->tasks;2->goals;3->notes;else->items.filter{it.title.contains(search,true)||it.body.contains(search,true)}}
    val done=tasks.count{it.completed}
    val total=tasks.size
    val goalDone=goals.count{it.completed}

    Scaffold(
        containerColor=Bg,
        topBar={
            Column(Modifier.padding(horizontal=18.dp,vertical=12.dp)) {
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("یادآور من",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                        Text("هدف → برنامه → قدم بعدی",color=Color.LightGray)
                    }
                    IconButton(onClick={focus=true}) { Icon(Icons.Default.Timer,null,tint=Purple,modifier=Modifier.size(30.dp)) }
                }
                if(tab!=4) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),placeholder={Text("جست‌وجو…")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(18.dp))
                }
            }
        },
        bottomBar={
            NavigationBar(containerColor=Card) {
                listOf(Icons.Default.Home to "خانه",Icons.Default.CheckCircle to "کارها",Icons.Default.Flag to "هدف‌ها",Icons.Default.Notes to "یادداشت",Icons.Default.BarChart to "آمار").forEachIndexed{ i,p->
                    NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(p.first,null)},label={Text(p.second)})
                }
            }
        },
        floatingActionButton={
            if(tab==0||tab==1||tab==2||tab==3) FloatingActionButton(onClick={if(tab==2)addGoal=true else showAdd=true},containerColor=Purple){Icon(Icons.Default.Add,null)}
        }
    ){ pad->
        if(tab==4) StatsScreen(total,done,goals.size,goalDone,onFocus={focus=true})
        else if(tab==0) HomeScreen(total,done,goals.size,goalDone,tasks,goals,onAdd={showAdd=true},onGoal={addGoal=true})
        else if(tab==2) GoalsScreen(goals,vm)
        else ListScreen(visible,vm,tab)
    }

    if(showAdd) AddItemDialog(
        onDismiss={showAdd=false},
        onSave={title,body,task,important,priority,category,reminder->
            if(task) { vm.addTask(title,body,important,priority,category,reminder); if(reminder!=null)scheduleReminder(context,title,body,reminder) }
            else vm.addNote(title,body)
            showAdd=false
        }
    )
    if(addGoal) GoalDialog({addGoal=false}){t,d,i->vm.addGoal(t,d,i);addGoal=false}
    if(focus) FocusDialog{focus=false}
}

@Composable fun HomeScreen(total:Int,done:Int,gc:Int,gd:Int,tasks:List<NoteTask>,goals:List<Goal>,onAdd:()->Unit,onGoal:()->Unit){
    LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp,vertical=10.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){
        item{
            Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(22.dp),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(18.dp)){
                    Text("امروز",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(if(total==0)"هنوز کاری برای امروز ثبت نکرده‌ای." else "$done از $total کار انجام شده",color=Color.LightGray)
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress={if(total==0)0f else done.toFloat()/total},modifier=Modifier.fillMaxWidth(),color=Purple)
                }
            }
        }
        item{
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp),modifier=Modifier.fillMaxWidth()){
                QuickCard("➕","کار جدید",onAdd,Modifier.weight(1f))
                QuickCard("🎯","هدف جدید",onGoal,Modifier.weight(1f))
            }
        }
        item{
            Text("هدف‌های در حال انجام",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)
        }
        items(goals.filter{!it.completed}.take(3),key={it.id}){g->
            Card(colors=CardDefaults.cardColors(containerColor=Card),modifier=Modifier.fillMaxWidth()){
                Column(Modifier.padding(15.dp)){
                    Row(verticalAlignment=Alignment.CenterVertically){
                        Text(g.title,Modifier.weight(1f),fontWeight=FontWeight.SemiBold)
                        Text("${g.progress}%")
                    }
                    Spacer(Modifier.height(7.dp))
                    LinearProgressIndicator(progress={g.progress/100f},modifier=Modifier.fillMaxWidth(),color=Purple)
                }
            }
        }
        if(tasks.isNotEmpty()) item{Text("کارهای بعدی",style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold)}
        items(tasks.filter{!it.completed}.take(3),key={it.id}){t->Text("• ${t.title}",color=Color.LightGray)}
    }
}
@Composable fun QuickCard(icon:String,title:String,onClick:()->Unit,modifier:Modifier){
    Card(onClick=onClick,colors=CardDefaults.cardColors(containerColor=Card),modifier=modifier,shape=RoundedCornerShape(18.dp)){
        Column(Modifier.padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(icon,style=MaterialTheme.typography.headlineSmall);Text(title)}
    }
}
@Composable fun ListScreen(list:List<NoteTask>,vm:MainViewModel,tab:Int){
    if(list.isEmpty()) Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("موردی پیدا نشد",color=Color.Gray)}
    else LazyColumn(Modifier.fillMaxSize().padding(horizontal=18.dp),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=90.dp)){items(list,key={it.id}){ItemCard(it,vm)}}
}
@Composable fun ItemCard(item:NoteTask,vm:MainViewModel){
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){
        Row(Modifier.padding(14.dp),verticalAlignment=Alignment.Top){
            if(item.isTask) Checkbox(item.completed,{vm.toggle(item)}) else Icon(Icons.Default.Notes,null,tint=Purple,modifier=Modifier.padding(8.dp))
            Column(Modifier.weight(1f).padding(horizontal=7.dp)){
                Text(item.title,fontWeight=FontWeight.SemiBold,textDecoration=if(item.completed)TextDecoration.LineThrough else null)
                if(item.body.isNotBlank())Text(item.body,color=Color.LightGray,maxLines=2)
                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ if(item.priority>=2)Text("اولویت بالا",color=Purple,style=MaterialTheme.typography.labelSmall); if(item.category!="عمومی")Text(item.category,color=Color.Gray,style=MaterialTheme.typography.labelSmall)}
                item.reminderAt?.let{Text("یادآوری: ${formatDate(it)}",color=Purple,style=MaterialTheme.typography.labelSmall)}
            }
            Column{
                IconButton({vm.star(item)}){Icon(if(item.important)Icons.Default.Star else Icons.Default.StarBorder,null,tint=if(item.important)Color(0xFFFFC857) else Color.Gray)}
                IconButton({vm.delete(item)}){Icon(Icons.Default.DeleteOutline,null,tint=Color.Gray)}
            }
        }
    }
}
@Composable fun GoalsScreen(goals:List<Goal>,vm:MainViewModel){
    if(goals.isEmpty())Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Text("اولین هدفت را با + بساز",color=Color.Gray)}
    else LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){items(goals,key={it.id}){g->
        Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){
            Column(Modifier.padding(16.dp)){
                Row(verticalAlignment=Alignment.CenterVertically){Text(g.title,Modifier.weight(1f),fontWeight=FontWeight.Bold);IconButton({vm.star(g)}){Icon(if(g.important)Icons.Default.Star else Icons.Default.StarBorder,null,tint=if(g.important)Color(0xFFFFC857)else Color.Gray)}}
                if(g.description.isNotBlank())Text(g.description,color=Color.LightGray)
                Spacer(Modifier.height(10.dp));LinearProgressIndicator(progress={g.progress/100f},modifier=Modifier.fillMaxWidth(),color=Purple)
                Spacer(Modifier.height(6.dp));Row(verticalAlignment=Alignment.CenterVertically){Text("${g.progress}%");Spacer(Modifier.weight(1f));TextButton({vm.progress(g,-10)},enabled=g.progress>0){Text("−۱۰")};TextButton({vm.progress(g,10)},enabled=g.progress<100){Text("+۱۰")};IconButton({vm.delete(g)}){Icon(Icons.Default.DeleteOutline,null)}}
            }
        }
    }}
}
@Composable fun StatsScreen(total:Int,done:Int,gc:Int,gd:Int,onFocus:()->Unit){
    Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        Text("آمار و تمرکز",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        StatCard("کارهای انجام‌شده","$done از $total",if(total==0)0 else done*100/total)
        StatCard("هدف‌های کامل‌شده","$gd از $gc",if(gc==0)0 else gd*100/gc)
        Button(onClick=onFocus,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.Timer,null);Spacer(Modifier.width(8.dp));Text("شروع تایمر تمرکز")}
        Text("با ثبت کارها و پیشرفت هدف‌ها، آمار شخصی‌ات به‌روز می‌شود.",color=Color.LightGray)
    }
}
@Composable fun StatCard(title:String,value:String,p:Int){
    Card(colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Row{Text(title,Modifier.weight(1f));Text(value,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(9.dp));LinearProgressIndicator(progress={p/100f},modifier=Modifier.fillMaxWidth(),color=Purple)}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddItemDialog(onDismiss:()->Unit,onSave:(String,String,Boolean,Boolean,Int,String,Long?)->Unit){
    var title by remember{mutableStateOf("")};var body by remember{mutableStateOf("")};var task by remember{mutableStateOf(true)};var important by remember{mutableStateOf(false)}
    var priority by remember{mutableIntStateOf(1)};var category by remember{mutableStateOf("عمومی")};var reminder by remember{mutableStateOf(false)};var selected by remember{mutableStateOf<Long?>(null)};var showTime by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("مورد جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        OutlinedTextField(title,{title=it},label={Text("عنوان")},singleLine=true,modifier=Modifier.fillMaxWidth())
        OutlinedTextField(body,{body=it},label={Text("توضیحات")},minLines=2,modifier=Modifier.fillMaxWidth())
        Row{FilterChip(task,{task=true},{Text("کار")});Spacer(Modifier.width(8.dp));FilterChip(!task,{task=false},{Text("یادداشت")})}
        if(task){Row(verticalAlignment=Alignment.CenterVertically){Checkbox(important,{important=it});Text("مهم");Spacer(Modifier.width(8.dp));Text("اولویت");Spacer(Modifier.width(4.dp));FilterChip(priority==2,{priority=2},{Text("بالا")});Spacer(Modifier.width(4.dp));FilterChip(priority==1,{priority=1},{Text("عادی")})}
            Row(verticalAlignment=Alignment.CenterVertically){Checkbox(reminder,{reminder=it;if(it)showTime=true else selected=null});Text("یادآوری")};selected?.let{Text(formatDate(it),color=Purple)}
        }}
    },confirmButton={TextButton(enabled=title.isNotBlank(),onClick={onSave(title,body,task,important,priority,category,selected)}){Text("ذخیره")}},dismissButton={TextButton(onDismiss){Text("انصراف")}})
    if(showTime){val picker=rememberTimePickerState();AlertDialog(onDismissRequest={showTime=false},confirmButton={TextButton({val c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,picker.hour);c.set(Calendar.MINUTE,picker.minute);c.set(Calendar.SECOND,0);if(c.timeInMillis<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);selected=c.timeInMillis;showTime=false}){Text("تأیید")}},dismissButton={TextButton({showTime=false}){Text("لغو")}},text={TimePicker(picker)},title={Text("زمان یادآوری")})}
}
@Composable fun GoalDialog(onDismiss:()->Unit,onSave:(String,String,Boolean)->Unit){
    var t by remember{mutableStateOf("")};var d by remember{mutableStateOf("")};var imp by remember{mutableStateOf(false)}
    AlertDialog(onDismissRequest=onDismiss,title={Text("هدف جدید")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(t,{t=it},label={Text("عنوان هدف")},singleLine=true);OutlinedTextField(d,{d=it},label={Text("توضیحات")},minLines=2);Row(verticalAlignment=Alignment.CenterVertically){Checkbox(imp,{imp=it});Text("هدف مهم")}}},confirmButton={TextButton(enabled=t.isNotBlank(),onClick={onSave(t,d,imp)}){Text("ساخت هدف")}},dismissButton={TextButton(onDismiss){Text("انصراف")}})
}
@Composable fun FocusDialog(onDismiss:()->Unit){
    var seconds by remember{mutableIntStateOf(25*60)};var running by remember{mutableStateOf(false)}
    LaunchedEffect(running){while(running&&seconds>0){kotlinx.coroutines.delay(1000);seconds--};if(seconds==0)running=false}
    AlertDialog(onDismissRequest=onDismiss,title={Text("تایمر تمرکز")},text={Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){
        Text(String.format("%02d:%02d",seconds/60,seconds%60),style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(14.dp));Text("۲۵ دقیقه تمرکز، سپس یک استراحت کوتاه.",color=Color.LightGray)
    }},confirmButton={TextButton({running=!running}){Text(if(running)"توقف" else "شروع")}},dismissButton={TextButton({seconds=25*60;running=false}){Text("شروع دوباره")}})
}
fun formatDate(ms:Long)=SimpleDateFormat("HH:mm - yyyy/MM/dd",Locale.US).format(Date(ms))
fun scheduleReminder(context:Context,title:String,body:String,at:Long){
    val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent=Intent(context,ReminderReceiver::class.java).apply{putExtra("title",title);putExtra("body",body)}
    val pi=PendingIntent.getBroadcast(context,(at%Int.MAX_VALUE).toInt(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    if(android.os.Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi) else am.set(AlarmManager.RTC_WAKEUP,at,pi)
}
